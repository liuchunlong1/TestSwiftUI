//
//  ContentView.swift
//  TestSwiftUI
//
//  Created by lclMac on 2021/1/24.
//

import Foundation
import SwiftUI
import AVKit

struct TileView: View {
    
    var icon: String
    var color: Color
    
    var body: some View {
        var url  = URL(string: icon)
        
        VStack {
            ZStack {
                Rectangle()
                    .fill(color)
                    .cornerRadius(20.0)
                AsyncImage(
                    url: url!,
                   placeholder: { Text("Loading ...") },
                   image: { Image(uiImage: $0).resizable() }
                )
                
            }
        }
    }
}

struct VideoView: View {
    
    var icon: String
    var color: Color
    
    var body: some View {
        var url  = URL(string: icon)
        
        VStack {
            ZStack {
                Rectangle()
                    .fill(color)
                    .cornerRadius(20.0)
                VideoPlayer(player: AVPlayer(url: url!))
            }
        }
    }
}

struct ContentView: View {
    @ObservedObject var networkingManager = NetworkingManager()
    
    @State private var scrollEffectValue: Double = 13
    @State private var activePageIndex: Int = 0
    
    let tileWidth: CGFloat = UIScreen.main.bounds.width;
    let tilePadding: CGFloat = 0
    //let numberOfTiles: Int = 10
    
    let tileWidth1: CGFloat = 200
    let tilePadding1: CGFloat = 30
    
    
    var items = [Color.red, Color.orange, Color.yellow, Color.green,         Color.blue, Color.purple,Color.red, Color.orange, Color.yellow, Color.green,         Color.blue, Color.purple]
    
    
    
    
    
    
    var body: some View {
        var nums = networkingManager.dataList.count;
        if(nums >  0){
            VStack {
                Spacer()
                self.renderTopView()
                self.renderListView()
                self.renderBottomView()
                Spacer()
            }
        }
        
        
    }
    
    
    func renderTopView() -> some View{
        GeometryReader { geometry in
            PagingScrollView(activePageIndex: self.$activePageIndex, itemCount:networkingManager.dataList.count ,pageWidth:geometry.size.width, tileWidth:self.tileWidth, tilePadding: self.tilePadding){
                ForEach(0 ..< networkingManager.dataList.count) { index in
                    GeometryReader { geometry2 in
                        VideoView(icon: networkingManager.dataList[index].videoUrl,color:self.items[index])
                            .scaleEffect(1.0)
                            .onTapGesture {
                                print ("tap on index: \(index) current:\(self.$activePageIndex)")
                        }
                    }
                }
            }
        }.frame(height:300)
    }
    
    
    func renderListView() -> some View{
        List{
            Text("current:\(self.activePageIndex)")
            Text("current:\(self.items[self.activePageIndex].description)")
        }
    }
    
    func renderBottomView() -> some View{
        GeometryReader { geometry in
            PagingScrollView(activePageIndex: self.$activePageIndex, itemCount:networkingManager.dataList.count ,pageWidth:geometry.size.width, tileWidth:self.tileWidth1, tilePadding: self.tilePadding1){
                ForEach(0 ..< networkingManager.dataList.count) { index in
                    GeometryReader { geometry2 in
                        TileView(icon: networkingManager.dataList[index].imageUrl,color:self.items[index])
                            .scaleEffect(self.activePageIndex == index ? 0.9 : 0.6)
                            .onTapGesture {
                                print ("tap on index: \(index) current:\(self.$activePageIndex)")
                        }
                    }
                }
            }
        }.frame(width: UIScreen.main.bounds.size.width, height: 300, alignment: .center)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
