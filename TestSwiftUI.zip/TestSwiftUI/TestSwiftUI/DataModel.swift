//
//  DataModel.swift
//  SwiftUIPagingScrollView
//
//  Created by lclMac on 2021/1/24.
//  Copyright © 2021 Nerdyak. All rights reserved.
//

import Foundation



struct ImageModels: Decodable, Hashable {
    var id: Int
    var imageUrl: String
    var videoUrl: String
    
}


struct DataAPIList: Decodable {
    var lists: [ImageModels]
}
