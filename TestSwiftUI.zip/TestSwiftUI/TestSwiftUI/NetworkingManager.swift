//
//  NetworkingManager.swift
//  SwiftUIPagingScrollView
//
//  Created by lclMac on 2021/1/24.
//  Copyright © 2021 Nerdyak. All rights reserved.
//

import Foundation

class NetworkingManager : ObservableObject {
 
  
    @Published var dataList :[ImageModels] = [];
  
  init() {
      guard let url = URL(string: "http://private-04a55-videoplayer1.apiary-mock.com/pictures") else {return}
      
      URLSession.shared.dataTask(with: url) {
          (data, _, _) in
          guard let data = data else {return}
          
          let dataList = try! JSONDecoder().decode([ImageModels].self, from: data)
          
          DispatchQueue.main.async {
              self.dataList = dataList
              
             // print(dataList.features)
              
              
          }
      }.resume()
  }
}
